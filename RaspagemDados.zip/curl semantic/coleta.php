

<?php

header('Cache-Control: no-cache');
header('Content-type: application/json; charset="utf-8"', true);

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,"https://balneabilidade.ima.sc.gov.br/relatorio/historico");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,"municipioID=24&localID=40&ano=2018&redirect=true");

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$html = curl_exec($ch);

$doc = new DOMDocument();

$doc->loadHTML($html);
// $dados = $doc->loadHtml($html);

$tables = $doc->getElementsByTagName('table');


$coletas = []; 

foreach ($tables as $key=>$table) {
    if ($key % 2 != 0){

        $pontos = [];
        
        //somente funciona nas tabelas impares
        $labels = $table->getElementsByTagName('label');
	
        foreach ($labels as $label){
									
     		$pedacos = explode(': ', $label->textContent);       

            $titulo = str_replace(" ", "_", preg_replace("/&([a-z])[a-z]+;/i", "$1", htmlentities(trim($pedacos[0]))));
     																	
     		$valor = $pedacos[1];							

     		$pontos[$titulo] = $valor; // armazeno o arry ponto dentro de pontos

        }
    }else{ //tabelas pares

        $coletadados = [];
        $linhas = $table->getElementsByTagName('tr');

        foreach ($linhas as $linha) {
        
            $celulas = $linha->getElementsByTagName('td');
               
            foreach ($celulas as $celula){

                $celulle = $celula->getAttribute('class');
                    if ($celulle != null) $coletadados[$celulle] = $celula->textContent;
                     
                        }
                              
                $pontos[] = array_filter($coletadados);
                                                
                }    


    }

    $coletas[$key] = array_filter($pontos);

}


echo json_encode(array_filter($coletas));



?>